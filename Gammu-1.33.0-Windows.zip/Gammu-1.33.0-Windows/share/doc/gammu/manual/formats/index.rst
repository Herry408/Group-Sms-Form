.. _formats:

File formats used by Gammu
==========================

Gammu understands wide range of standard formats as well as introduces own
formats for storing some data.

.. toctree::
    :maxdepth: 2

    ini
    smsbackup
    backup
