About Gammu
===========

Gammu is library and command line utility for mobile phones. It is
released under GNU GPL version 2.

It has been initiated by Marcin Wiacek and other people. Originally the
code was based on `Gnokii`_ and later `MyGnokii`_ projects. Gammu  was former (up to version
0.58) called MyGnokii2.

Currently the project is lead by `Michal Čihař`_ with
help of many contributors.

.. _Gnokii: http://www.gnokii.org
.. _MyGnokii:  http://www.mwiacek.com
.. _Michal Čihař: mailto:michal@cihar.com
