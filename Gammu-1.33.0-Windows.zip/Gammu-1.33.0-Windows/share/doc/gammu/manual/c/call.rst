Call
====

.. doxygenfunction:: GSM_DialVoice
.. doxygenfunction:: GSM_DialService
.. doxygenfunction:: GSM_AnswerCall
.. doxygenfunction:: GSM_CancelCall
.. doxygenfunction:: GSM_HoldCall
.. doxygenfunction:: GSM_UnholdCall
.. doxygenfunction:: GSM_ConferenceCall
.. doxygenfunction:: GSM_SplitCall
.. doxygenfunction:: GSM_TransferCall
.. doxygenfunction:: GSM_SwitchCall
.. doxygenfunction:: GSM_GetCallDivert
.. doxygenfunction:: GSM_SetCallDivert
.. doxygenfunction:: GSM_CancelAllDiverts
.. doxygenfunction:: GSM_SetIncomingCall
.. doxygenfunction:: GSM_SendDTMF
.. doxygenenum:: GSM_CallStatus
.. doxygenstruct:: GSM_Call
.. doxygenenum:: GSM_Divert_DivertTypes
.. doxygenenum:: GSM_Divert_CallTypes
.. doxygenstruct:: GSM_CallDivert
.. doxygenstruct:: GSM_MultiCallDivert
.. doxygenenum:: GSM_CallShowNumber
