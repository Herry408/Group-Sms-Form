Security
========

.. doxygenfunction:: GSM_EnterSecurityCode
.. doxygenfunction:: GSM_GetSecurityStatus
.. doxygenenum:: GSM_SecurityCodeType
.. doxygenstruct:: GSM_SecurityCode
