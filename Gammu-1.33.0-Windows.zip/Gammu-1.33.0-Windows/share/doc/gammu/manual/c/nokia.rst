Nokia
=====

.. doxygenfunction:: NOKIA_GetDefaultCallerGroupName
.. doxygenfunction:: NOKIA_GetDefaultProfileName
