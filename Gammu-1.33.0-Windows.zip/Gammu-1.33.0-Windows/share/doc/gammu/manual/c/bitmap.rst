Bitmap
======

.. doxygenfunction:: GSM_GetBitmap
.. doxygenfunction:: GSM_SetBitmap
.. doxygenfunction:: GSM_PrintBitmap
.. doxygenfunction:: GSM_SaveBitmapFile
.. doxygenfunction:: GSM_ReadBitmapFile
.. doxygenfunction:: GSM_IsPointBitmap
.. doxygenfunction:: GSM_SetPointBitmap
.. doxygenfunction:: GSM_ClearPointBitmap
.. doxygenfunction:: GSM_ClearBitmap
.. doxygenenum:: GSM_BinaryPicture_Types
.. doxygenstruct:: GSM_BinaryPicture
.. doxygenenum:: GSM_Bitmap_Types
.. doxygenstruct:: GSM_Bitmap
.. doxygenstruct:: GSM_MultiBitmap
.. doxygenfunction:: GSM_GetScreenshot
